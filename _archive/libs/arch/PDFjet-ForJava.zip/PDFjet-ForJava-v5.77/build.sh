#!/bin/bash

javac -encoding utf-8 -Xlint -cp .:PDFjet.jar *.java

java -cp .:PDFjet.jar Example_01
java -cp .:PDFjet.jar Example_02
java -cp .:PDFjet.jar Example_03
java -cp .:PDFjet.jar Example_04
java -cp .:PDFjet.jar Example_05
java -cp .:PDFjet.jar Example_06
java -cp .:PDFjet.jar Example_07
java -cp .:PDFjet.jar Example_08
java -cp .:PDFjet.jar Example_09
java -cp .:PDFjet.jar Example_10
java -cp .:PDFjet.jar Example_11
java -cp .:PDFjet.jar Example_12
java -cp .:PDFjet.jar Example_13
java -cp .:PDFjet.jar Example_14
java -cp .:PDFjet.jar Example_15
java -cp .:PDFjet.jar Example_16
java -cp .:PDFjet.jar Example_17
java -cp .:PDFjet.jar Example_18
java -cp .:PDFjet.jar Example_19
java -cp .:PDFjet.jar Example_20 Example_07.pdf
java -cp .:PDFjet.jar Example_21
java -cp .:PDFjet.jar Example_22
java -cp .:PDFjet.jar Example_23
java -cp .:PDFjet.jar Example_24
java -cp .:PDFjet.jar Example_25
java -cp .:PDFjet.jar Example_26
java -cp .:PDFjet.jar Example_27
java -cp .:PDFjet.jar Example_28
java -cp .:PDFjet.jar Example_29
java -cp .:PDFjet.jar Example_30
java -cp .:PDFjet.jar Example_31
java -cp .:PDFjet.jar Example_32
java -cp .:PDFjet.jar Example_33
java -cp .:PDFjet.jar Example_34
java -cp .:PDFjet.jar Example_35
java -cp .:PDFjet.jar Example_36
java -cp .:PDFjet.jar Example_37
java -cp .:PDFjet.jar Example_38
java -cp .:PDFjet.jar Example_39
java -cp .:PDFjet.jar Example_40
java -cp .:PDFjet.jar Example_41
java -cp .:PDFjet.jar Example_42
java -cp .:PDFjet.jar Example_43
java -cp .:PDFjet.jar Example_44
java -cp .:PDFjet.jar Example_45
java -cp .:PDFjet.jar Example_46
java -cp .:PDFjet.jar Example_47
java -cp .:PDFjet.jar Example_48
java -cp .:PDFjet.jar Example_49
java -cp .:PDFjet.jar Example_50
java -cp .:PDFjet.jar Example_51
java -cp .:PDFjet.jar Example_52
java -cp .:PDFjet.jar Example_53
